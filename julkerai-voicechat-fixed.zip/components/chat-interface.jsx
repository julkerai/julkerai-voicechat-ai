"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ initialMessage = "Hello! I'm your English tutor. I'm here to help you learn English. I can help with grammar, vocabulary, pronunciation, or just practice conversation. What would you like to work on today?" }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: initialMessage }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false); 
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState(null);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [voices, setVoices] = useState([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const messagesEndRef = useRef(null);
  const [particles, setParticles] = useState(Array.from({length: 20}).fill().map(() => ({
    id: Math.random(),
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 3 + 1,
    speed: Math.random() * 2 + 1
  })));

  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
      if (availableVoices.length > 0) {
        setSelectedVoice(availableVoices[0].name);
      }
    };

    window.speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices();

    const interval = setInterval(() => {
      setParticles(prev => prev.map(particle => ({
        ...particle,
        y: (particle.y + particle.speed) % 100,
        x: particle.x + Math.sin(particle.y / 10) * 0.5
      })));
    }, 50);

    return () => {
      clearInterval(interval);
      window.speechSynthesis.cancel();
    };
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const audioChunks = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks);
        const { url } = await upload({ file: audioBlob });
        setInputMessage(url);
      };

      setIsRecording(true);
      mediaRecorder.start();

      setTimeout(() => {
        mediaRecorder.stop();
        stream.getTracks().forEach(track => track.stop());
        setIsRecording(false);
      }, 5000);
    } catch (err) {
      console.error(err);
      setError('Microphone access denied');
      setIsRecording(false);
    }
  };

  const playMessage = async (text) => {
    if (!text || isSpeaking) return;
    
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const voice = voices.find(v => v.name === selectedVoice);
      if (voice) {
        utterance.voice = voice;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (error) => {
        console.error('Speech synthesis error:', error);
        setIsSpeaking(false);
        setError('Failed to play audio');
      };

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error(err);
      setError('Failed to play audio');
      setIsSpeaking(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMessage = { role: 'user', content: inputMessage };
    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: inputMessage }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const data = await response.json();
      setMessages(prev => [...prev, { 
        role: 'assistant',
        content: data.response
      }]);
      
      if (data.response) {
        playMessage(data.response);
      }
    } catch (err) {
      console.error(err);
      setError('Failed to send message. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex flex-col h-[600px] w-full max-w-2xl mx-auto bg-gradient-to-br from-[#0a0f2d] to-[#1a1f4c] rounded-xl border border-[#2a3366] shadow-[0_8px_32px_rgba(41,66,205,0.2)] backdrop-blur-lg overflow-hidden">
      <div className="p-4 border-b border-[#2a3366] bg-[#0a0f2d] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img src="/julker-ai-logo.png" alt="Julker AI Logo" className="h-8 w-8" />
          <span className="text-[#4a90e2] font-bold text-lg">Julker AI</span>
        </div>
        <select
          value={selectedVoice}
          onChange={(e) => setSelectedVoice(e.target.value)}
          className="px-3 py-1 rounded-lg bg-[#1a1f4c] border border-[#2a3366] text-sm text-[#4a90e2] focus:ring-2 focus:ring-[#4a90e2] transition-all duration-300"
        >
          {voices.map((voice) => (
            <option key={voice.name} value={voice.name}>
              {voice.name} ({voice.lang})
            </option>
          ))}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 relative z-10">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute rounded-full bg-[#4a90e2] opacity-10 pointer-events-none animate-float"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              filter: 'blur(2px)',
            }}
          />
        ))}

        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} animate-slideIn`}
          >
            <div
              className={`max-w-[80%] rounded-2xl p-4 shadow-lg transition-all duration-300 hover:shadow-2xl transform hover:scale-[1.02] ${
                message.role === 'user'
                  ? 'bg-gradient-to-r from-[#4a90e2] to-[#357abd] text-white animate-userSlide'
                  : 'bg-gradient-to-r from-[#1a1f4c] to-[#2a3366] border border-[#4a90e2] text-[#fff] animate-aiSlide relative overflow-hidden'
              }`}
              style={{
                transform: 'perspective(1000px) rotateX(5deg)',
                transformStyle: 'preserve-3d',
              }}
            >
              {message.role === 'assistant' && (
                <div className="absolute inset-0 bg-[#4a90e2] opacity-10 animate-pulse-slow"></div>
              )}
              <div className="flex items-start gap-3 relative z-10">
                <p className={`text-sm font-inter leading-relaxed ${message.role === 'assistant' ? 'animate-typing-new' : ''}`}>
                  {message.content}
                </p>
                {message.role === 'assistant' && (
                  <button
                    onClick={() => playMessage(message.content)}
                    disabled={isSpeaking}
                    className={`p-2 rounded-full backdrop-blur-lg transition-all duration-300 transform hover:scale-110 ${
                      isSpeaking
                        ? 'bg-[#4a90e2] text-white animate-glow'
                        : 'bg-[#1a1f4c] border border-[#4a90e2] text-[#4a90e2] hover:bg-[#4a90e2] hover:text-white'
                    }`}
                  >
                    <i className={`fas ${isSpeaking ? 'fa-wave-square' : 'fa-volume-up'} animate-cyber`}></i>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start animate-fadeIn">
            <div className="max-w-[80%] rounded-2xl p-4 bg-gradient-to-r from-[#1a1f4c] to-[#2a3366] shadow-lg border border-[#4a90e2]">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-[#4a90e2] rounded-full animate-cyber-bounce"></div>
                <div className="w-3 h-3 bg-[#4a90e2] rounded-full animate-cyber-bounce delay-100"></div>
                <div className="w-3 h-3 bg-[#4a90e2] rounded-full animate-cyber-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="text-[#ff4a4a] text-sm text-center font-inter animate-shake">{error}</div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-[#2a3366] bg-[#0a0f2d] rounded-b-xl relative z-10">
        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={startRecording}
            disabled={isRecording}
            className={`p-3 rounded-full backdrop-blur-lg transition-all duration-300 transform hover:scale-110 ${
              isRecording
                ? 'bg-[#4a90e2] text-white animate-glow'
                : 'bg-[#1a1f4c] border border-[#4a90e2] text-[#4a90e2] hover:bg-[#4a90e2] hover:text-white'
            }`}
          >
            <i className={`fas ${isRecording ? 'fa-microphone-slash animate-pulse' : 'fa-microphone'}`}></i>
          </button>
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Type your message here..."
            className="flex-1 p-3 rounded-xl border border-[#2a3366] bg-[#1a1f4c] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#4a90e2] transition-all duration-300"
          />
          <button
            type="submit"
            disabled={isLoading || !inputMessage.trim()}
            className="px-6 py-3 bg-gradient-to-r from-[#4a90e2] to-[#357abd] text-white rounded-xl font-inter font-medium hover:from-[#357abd] hover:to-[#4a90e2] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shadow-[0_0_15px_rgba(74,144,226,0.3)] hover:shadow-[0_0_25px_rgba(74,144,226,0.5)]"
          >
            Send
          </button>
        </div>
      </form>

      <style jsx global>{`
        @keyframes slideIn {
          from { transform: translateY(20px) perspective(1000px) rotateX(10deg); opacity: 0; }
          to { transform: translateY(0) perspective(1000px) rotateX(5deg); opacity: 1; }
        }
        @keyframes userSlide {
          from { transform: translateX(20px) perspective(1000px) rotateX(10deg); opacity: 0; }
          to { transform: translateX(0) perspective(1000px) rotateX(5deg); opacity: 1; }
        }
        @keyframes aiSlide {
          from { transform: translateX(-20px) perspective(1000px) rotateX(10deg); opacity: 0; }
          to { transform: translateX(0) perspective(1000px) rotateX(5deg); opacity: 1; }
        }
        @keyframes typing-new {
          0% { width: 0; opacity: 0; }
          100% { width: 100%; opacity: 1; }
        }
        @keyframes cyber {
          0% { transform: scale(1) rotate(0deg); }
          50% { transform: scale(1.2) rotate(180deg); }
          100% { transform: scale(1) rotate(360deg); }
        }
        @keyframes cyber-bounce {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-10px) scale(1.2); }
        }
        @keyframes glow {
          0% { box-shadow: 0 0 5px #4a90e2; }
          50% { box-shadow: 0 0 20px #4a90e2; }
          100% { box-shadow: 0 0 5px #4a90e2; }
        }
        @keyframes pulse-slow {
          0% { opacity: 0.1; }
          50% { opacity: 0.2; }
          100% { opacity: 0.1; }
        }
        .animate-typing-new { 
          display: inline-block;
          overflow: hidden;
          white-space: nowrap;
          animation: typing-new 1s ease-out;
        }
        .animate-cyber { animation: cyber 2s infinite; }
        .animate-cyber-bounce { animation: cyber-bounce 1s infinite; }
        .animate-glow { animation: glow 2s infinite; }
        .animate-pulse-slow { animation: pulse-slow 3s infinite; }
      `}</style>
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-4 min-h-screen bg-gradient-to-br from-[#050824] to-[#0a0f2d]">
      <MainComponent />
      <div className="mt-8">
        <MainComponent initialMessage="Welcome to Julker AI! I'm your advanced English tutor powered by cutting-edge artificial intelligence. How can I assist you today?" />
      </div>
    </div>
  );
});
}
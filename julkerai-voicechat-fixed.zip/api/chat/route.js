async function handler({ message, context, user }) {
  const FREE_MESSAGES_PER_DAY = 5;

  if (!message) {
    return {
      response:
        "Hi! I'm your English tutor. Let's practice speaking together. I can help with pronunciation, vocabulary, or conversation.",
      audio: null,
      isPremium: user?.isPremium || false,
    };
  }

  const isPremium = user?.isPremium || false;
  const userMessageCount = user?.messageCount || 0;

  if (!isPremium && userMessageCount >= FREE_MESSAGES_PER_DAY) {
    return {
      response:
        "You've reached your daily message limit. Upgrade to premium for unlimited conversations!",
      audio: null,
      isPremium,
      isLimited: true,
    };
  }

  const systemPrompt = `You are an advanced English language tutor. Analyze the user's message and provide:
1. Main response (keep it natural and conversational)
2. Language corrections (if any mistakes found)
3. Pronunciation guide (using IPA when needed)
4. Grammar explanation (if relevant)
5. Vocabulary suggestions (2-3 alternative words/phrases)

Format the response as a JSON object with these fields. Keep each section brief and focused.`;

  const jsonSchema = {
    name: "english_tutor_response",
    schema: {
      type: "object",
      properties: {
        mainResponse: { type: "string" },
        corrections: { type: "string" },
        pronunciation: { type: "string" },
        grammar: { type: "string" },
        vocabulary: { type: "string" },
      },
      required: [
        "mainResponse",
        "corrections",
        "pronunciation",
        "grammar",
        "vocabulary",
      ],
      additionalProperties: false,
    },
  };

  const response = await fetch("/integrations/google-gemini-1-5/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: message,
        },
      ],
      json_schema: jsonSchema,
    }),
  });

  const data = await response.json();

  if (!data.choices || !data.choices[0]) {
    return {
      response: "Could you say that again?",
      audio: null,
      isPremium,
    };
  }

  const aiResponse = JSON.parse(data.choices[0].message.content);

  const formattedResponse = isPremium
    ? `${aiResponse.mainResponse}\n\n${
        aiResponse.corrections
          ? `🔍 Corrections: ${aiResponse.corrections}\n`
          : ""
      }${
        aiResponse.pronunciation
          ? `🗣 Pronunciation: ${aiResponse.pronunciation}\n`
          : ""
      }${aiResponse.grammar ? `📚 Grammar: ${aiResponse.grammar}\n` : ""}${
        aiResponse.vocabulary ? `📖 Vocabulary: ${aiResponse.vocabulary}` : ""
      }`
    : aiResponse.mainResponse;

  const audioResponse = await fetch("/api/text-to-audio-converter", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      text: aiResponse.mainResponse,
    }),
  });

  const audioData = await audioResponse.json();

  if (isPremium) {
    try {
      await fetch("/api/save-chat-history", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          message,
          response: aiResponse,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error("Failed to save chat history:", error);
    }
  }

  return {
    response: formattedResponse,
    audio: audioData,
    isPremium,
    details: isPremium
      ? {
          corrections: aiResponse.corrections,
          pronunciation: aiResponse.pronunciation,
          grammar: aiResponse.grammar,
          vocabulary: aiResponse.vocabulary,
        }
      : null,
  };
}